Run the following: gcc smallsh.c -o smallsh

The grading script may hang near the end when it's testing out the foreground-only mode. I am not sure why it does this, but when the foreground-only mode commands are tested manually, they work perfectly fine. 